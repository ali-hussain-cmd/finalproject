package com.example.prophoto;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class photo2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo2);
        Bundle b = getIntent().getExtras();
        photo p = (photo) b.getSerializable("photo");



        ImageView img = findViewById(R.id.imageView3);
        TextView name = findViewById(R.id.textView2);
        TextView price = findViewById(R.id.textView6);
        TextView description =findViewById(R.id.textView7);


        img.setImageResource(p.getImage());
        name.setText(p.getName());
        price.setText(p.getPrice()+"");
        description.setText(p.getDescription());

    }
}