package com.example.prophoto;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        ArrayList<photo> name = new ArrayList<>();

        photo no1 = new photo("CANON EOS 2000D",R.drawable.eos_2000d,119,"24Mp APS-C CMOS sensor\n" +
                "Canon EF-S lens mount\n" +
                "3fps continuous shooting\n" +
                "Full-HD (1920 x 1080) video at 30, 25 or 24fps\n" +
                "Wi-Fi/NFC");
        photo no2 = new photo("CANON EOS R6 (BODY ONLY)",R.drawable.canoneosr6,799,"20MP Full-Frame CMOS Sensor\n" +
                "DIGIC X Image Processor\n" +
                "4K60p and FHD 120p 10-Bit Internal Video\n" +
                "Sensor-Shift 5-Axis Image Stabilization");
        photo no3 = new photo("CANON EOS R5 (BODY ONLY)",R.drawable.r5_prophoto,1390,"Expected availability: END OF NOVEMBER\n" +
                "45MP Full-Frame CMOS SensoR\n" +
                "8K30 Raw and 4K120 10-Bit Internal Video\n" +
                "Rear Underslung Handle in Compact Design\n" +
                "Highly Upgraded Motors and Algorithm");
        photo no4 = new photo("CANON EOS 80D",R.drawable.eos80d,299,"4.2MP APS-C CMOS Sensor\n" +
                "DIGIC 6 Image Processor\n" +
                "3.0\" 1.04m-Dot Vari-Angle Touchscreen\n" +
                "Full HD 1080p Video Recording at 60 fps");
        photo no5 = new photo("NIKON D-5600",R.drawable.nikon__5600,179,"24.2MP DX-Format CMOS Sensor - EXPEED 4 Image Processor - 3.2\" 1.037m-Dot Vari-Angle Touchscreen - Full HD 1080p Video Recording at 60 fps - Multi-CAM 4800DX 39-Point AF Sensor - ISO 100-25600 and 5 fps Shooting - SnapBridge Bluetooth and Wi-Fi with NFC - Time-Lapse Movie Recording - AF-P DX 18-55mm f/3.5-5.6G VR Lens");
        photo no6 = new photo("NIKON Z50",R.drawable.nikon_z_50,329,"20.9MP DX-Format CMOS Sensor\n" +
                "EXPEED 6 Image Processor\n" +
                "UHD 4K and Full HD Video Recording\n" +
                "2.36m-Dot OLED Electronic Viewfinder");
        photo no7 = new photo("NIKON COOLPIX P1000",R.drawable.nikon_coolpix_p1000_digital_camera,299,"NIKKOR 24-3000mm Lens (35mm Equivalent) - Aperture Range: f/2.8-8 - 16MP BSI CMOS Sensor - EXPEED Image Processor - ISO 100-6400 - 2.36m-Dot OLED EVF - 3.2\" 921k-Dot Vari-Angle LCD Monitor - 4K UHD Video Recording - SnapBridge via Wi-Fi or Bluetooth - Auto, Aperture, Shutter, Manual Modes");
        photo no8 = new photo("SONY ALPHA A7 III MIRRORLESS CAMERA (BODY ONLY)",R.drawable.sony_alpha_a7_iii_mirrorless_camera__body_only_,639,"24MP Full-Frame Exmor R BSI CMOS Sensor\n" +
                "BIONZ X Image Processor & Front-End LSI\n" +
                "693-Point Hybrid AF System\n" +
                "UHD 4K30p Video with HLG & S-Log3 Gammas");
        photo no9 = new photo("SONY ZV1 DIGITAL CAMERA",R.drawable.zv1,259,"20.1MP 1\" Exmor RS BSI CMOS Sensor\n" +
                "ZEISS 24-70mm-Equiv. f/1.8-2.8 Lens\n" +
                "UHD 4K30p Video with HLG & S-Log3 Gammas\n" +
                "3.0\" Side Flip-Out Touchscreen LCD");
        photo no10 = new photo("CANON LENS EF 85MM F/1.4 IS USM",R.drawable.canon_85mm,499,"EF-Mount Lens/Full-Frame Format\n" +
                "Aperture Range: f/1.4 to f/22\n" +
                "One Aspherical Element\n" +
                "Air Sphere Coating");
        photo no11 = new photo("SIGMA 12-24MM F/4 DG HSM ART LENS FOR NIKON F",R.drawable.nikon_12_24mm,479,"F-Mount Lens/FX Format\n" +
                "Aperture Range: f/4 to 22\n" +
                "FLD and Aspherical Elements\n" +
                "Super Multi-Layer Coating\n" +
                "Hyper Sonic AF Motor, Manual Override\n" +
                "Rounded 9-Blade Diaphragm\n" +
                "TSC Material, Brass Bayonet Mount\n" +
                "Dust- and Splash-Proof Construction\n" +
                "Compatible with Sigma USB Dock");
        photo no12 = new photo("SONY FE 12-24MM F/2.8 GM LENS",R.drawable.sony_12_24,949,"E-Mount Lens/Full-Frame Format\n" +
                "Aperture Range: f/2.8 to f/22\n" +
                "Three XA Elements, Two Super ED Elements\n" +
                "Nano AR II and Fluorine Coatings");
        photo no13 = new photo("NANLITE HALO 16C BI-COLOR LED RING LIGHT RGB MIRROR",R.drawable.nanlite_halo_16c_bi_color_led_ring_light_rgb_mirror,80,"Color Temp 2700-5600K, CRI/TLCI: 95/93\n" +
                "RGBWW Mode, Touchpad Control\n" +
                "Inner Opening: 12\", Carry Case\n" +
                "Includes Smartphone Bracket");
        photo no14 = new photo("SIGMA FLASH EF-630 EO-ETTL2 (CANON)",R.drawable.sigma_flash_ef_630_eo_ettl2__canon_,99,"Compatible with Canon E-TTL / E-TTL II\n" +
                "Guide Number: 207' at ISO 100 and 200mm\n" +
                "Zoom Range: 24-200mm (17mm with Panel)\n" +
                "Tilts from -7 to 90°\n" +
                "Rotates Left & Right 180°\n" +
                "Wireless Slave Functionality \n" +
                "Wireless TTL Functionality \n" +
                "Modeling Light Function; AF Assist Light\n" +
                "High-Speed Sync\n" +
                "Compatible with FD-11 Flash USB Dock\n" +
                " ");


        name.add(no1);
        name.add(no2);
        name.add(no3);
        name.add(no4);
        name.add(no5);
        name.add(no6);
        name.add(no7);
        name.add(no8);
        name.add(no9);
        name.add(no10);
        name.add(no11);
        name.add(no12);
        name.add(no13);
        name.add(no14);



        RecyclerView rv = findViewById(R.id.recyclerview);



        rv.setHasFixedSize(true);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        rv.setLayoutManager(lm);


        cameraAdapter cAdapter = new cameraAdapter(name, this);
        rv.setAdapter(cAdapter);



    }
    public void logout(View view){
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(getApplicationContext(),login.class));
        finish();
    }










}