package com.example.prophoto;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity2 extends AppCompatActivity {
    EditText Email,password1;
    Button Go;
    TextView mCreatebtn;
    FirebaseAuth fAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);




        final Button signup;

        signup = findViewById(R.id.button4);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity2.this,signup.class);
                startActivity(i);
                Email=findViewById(R.id.Email1);
                password1 =findViewById(R.id.pass1);
                fAuth = FirebaseAuth.getInstance();
                Go = findViewById(R.id.Go);

                Go.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String email = Email.getText().toString().trim();
                        String password = password1.getText().toString().trim();

                        if (TextUtils.isEmpty(email)){
                            Email.setError("Email is Required");
                            return;

                        }
                        if (TextUtils.isEmpty(password)){
                            password1.setError("password is Required");
                            return;
                        }
                        if (password.length()<6){
                            password1.setError("password Must be >= 6 characters");
                            return;
                        }
                        fAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()){
                                    Toast.makeText(MainActivity2.this, "Logged in successfully", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(getApplicationContext(),MainActivity3.class));
                                }else{
                                    Toast.makeText(MainActivity2.this, "Error !" +task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                        Go.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                startActivity(new Intent(getApplicationContext(),signup.class));
                            }
                        });

                    }

                });




    }
});}}