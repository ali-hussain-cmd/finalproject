package com.example.prophoto;

import android.content.Context;
import android.os.Parcelable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class cameraAdapter extends RecyclerView.Adapter {

    ArrayList<photo> cArray ;
    Context context;

    public cameraAdapter(ArrayList<photo> cArray, Context context) {
        this.cArray = cArray;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.rv_design,parent,false);
        ViewHolder vh = new ViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, final int position) {
        ((ViewHolder) holder).img.setImageResource(cArray.get(position).getImage());
        ((ViewHolder) holder).price.setText(cArray.get(position).getPrice()+ "");
        ((ViewHolder) holder).name.setText(cArray.get(position).getName());
      ((ViewHolder) holder).view.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View view) {
              Intent i = new Intent(context, photo2.class);
              i.putExtra("photo", cArray.get(position));
              context.startActivity(i);
          }
      });

    }
    @Override
    public int getItemCount() {
        return cArray.size();
    }

   public static class ViewHolder extends  RecyclerView.ViewHolder{
        public ImageView img ;
        public TextView name ;
        public TextView price ;
        public View view;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            view= itemView;
            img = view.findViewById(R.id.imageView2);
            name = view.findViewById(R.id.textView);
            price = view.findViewById(R.id.textView3);
        }
    }


}